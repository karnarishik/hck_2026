# PyRefine Backend 🚀

FastAPI backend for the PyRefine AI-powered Python code refiner.

## Features
- 🔐 JWT Authentication (register, login, /me)
- ⚡ Code refinement via Anthropic Claude API
- 📜 Per-user refinement history (save, list, delete)
- 🗄️ SQLite database (zero config)

## Quick Start

```bash
# 1. Clone & enter directory
cd pyrefine-backend

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set environment variables
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY and SECRET_KEY

# 5. Run the server
uvicorn main:app --reload --port 8000
```

## API Docs
Once running, visit: http://localhost:8000/docs

## Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /auth/register | Create account |
| POST | /auth/login | Login, get JWT |
| GET | /auth/me | Get current user |

### Refine
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /refine/ | Refine Python code |

**Body:**
```json
{
  "code": "def foo(): pass",
  "mode": "all"  // "all" | "bugs" | "performance" | "readability"
}
```

### History
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /history/ | List all refinements |
| GET | /history/{id} | Get one refinement |
| DELETE | /history/{id} | Delete one refinement |
| DELETE | /history/ | Clear all history |

## Deployment (Render / Railway)

Set these environment variables in your dashboard:
- `ANTHROPIC_API_KEY` — your Anthropic key
- `SECRET_KEY` — any long random string

Start command: `uvicorn main:app --host 0.0.0.0 --port 8000`
