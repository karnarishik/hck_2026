import json
from fastapi import APIRouter, Depends, HTTPException
from database import get_connection
from auth_utils import get_current_user

router = APIRouter()


@router.get("/")
def get_history(
    limit: int = 20,
    offset: int = 0,
    current_user: dict = Depends(get_current_user)
):
    conn = get_connection()
    rows = conn.execute(
        """SELECT id, mode, summary, created_at,
                  substr(original_code, 1, 120) as original_preview
           FROM refinements
           WHERE user_id = ?
           ORDER BY created_at DESC
           LIMIT ? OFFSET ?""",
        (current_user["id"], limit, offset)
    ).fetchall()

    total = conn.execute(
        "SELECT COUNT(*) FROM refinements WHERE user_id = ?",
        (current_user["id"],)
    ).fetchone()[0]
    conn.close()

    return {
        "total": total,
        "limit": limit,
        "offset": offset,
        "items": [dict(r) for r in rows]
    }


@router.get("/{refinement_id}")
def get_refinement(refinement_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM refinements WHERE id = ? AND user_id = ?",
        (refinement_id, current_user["id"])
    ).fetchone()
    conn.close()

    if not row:
        raise HTTPException(status_code=404, detail="Refinement not found")

    result = dict(row)
    result["issues"] = json.loads(result["issues"])
    return result


@router.delete("/{refinement_id}")
def delete_refinement(refinement_id: int, current_user: dict = Depends(get_current_user)):
    conn = get_connection()
    existing = conn.execute(
        "SELECT id FROM refinements WHERE id = ? AND user_id = ?",
        (refinement_id, current_user["id"])
    ).fetchone()

    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Refinement not found")

    conn.execute("DELETE FROM refinements WHERE id = ?", (refinement_id,))
    conn.commit()
    conn.close()
    return {"message": f"Refinement {refinement_id} deleted"}


@router.delete("/")
def clear_history(current_user: dict = Depends(get_current_user)):
    conn = get_connection()
    conn.execute("DELETE FROM refinements WHERE user_id = ?", (current_user["id"],))
    conn.commit()
    conn.close()
    return {"message": "All history cleared"}
