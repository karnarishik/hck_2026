import os
import json
import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Literal
from database import get_connection
from auth_utils import get_current_user

router = APIRouter()

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
MODEL = "claude-sonnet-4-20250514"

MODE_INSTRUCTIONS = {
    "all": "Fix bugs, optimize performance, AND improve readability/style",
    "bugs": "Focus primarily on identifying and fixing bugs and errors",
    "performance": "Focus primarily on optimizing performance (algorithmic complexity, memory usage, speed)",
    "readability": "Focus primarily on improving readability, naming conventions, PEP 8 style, and clarity"
}


class RefineRequest(BaseModel):
    code: str
    mode: Literal["all", "bugs", "performance", "readability"] = "all"


class RefineResponse(BaseModel):
    refined_code: str
    issues: list
    summary: str
    refinement_id: int


@router.post("/", response_model=RefineResponse)
async def refine_code(body: RefineRequest, current_user: dict = Depends(get_current_user)):
    if not body.code.strip():
        raise HTTPException(status_code=400, detail="Code cannot be empty")

    if len(body.code) > 20000:
        raise HTTPException(status_code=400, detail="Code too long (max 20,000 characters)")

    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY not configured")

    prompt = f"""You are an expert Python code refiner. The user wants you to: {MODE_INSTRUCTIONS[body.mode]}.

Analyze this Python code and return a JSON response (only JSON, no markdown) with this exact structure:
{{
  "refined_code": "...the complete improved Python code...",
  "issues": [
    {{"type": "bug|performance|style", "description": "brief description of what was found and fixed"}}
  ],
  "summary": "one sentence summary of changes made"
}}

Here is the code to refine:
```python
{body.code}
```

Rules:
- Return ONLY valid JSON, no backticks, no markdown
- Keep refined_code as a clean Python code string with \\n for newlines
- List 2-6 specific issues found
- Be precise and helpful"""

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                ANTHROPIC_URL,
                headers={
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                },
                json={
                    "model": MODEL,
                    "max_tokens": 4096,
                    "messages": [{"role": "user", "content": prompt}]
                }
            )
            response.raise_for_status()
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=502, detail=f"Anthropic API error: {e.response.text}")
    except httpx.RequestError as e:
        raise HTTPException(status_code=502, detail=f"Failed to reach Anthropic API: {str(e)}")

    raw = "".join(block.get("text", "") for block in response.json().get("content", []))

    try:
        clean = raw.replace("```json", "").replace("```", "").strip()
        parsed = json.loads(clean)
    except json.JSONDecodeError:
        raise HTTPException(status_code=502, detail="Failed to parse AI response as JSON")

    refined_code = parsed.get("refined_code", "")
    issues = parsed.get("issues", [])
    summary = parsed.get("summary", "")

    # Save to history
    conn = get_connection()
    cursor = conn.execute(
        """INSERT INTO refinements (user_id, mode, original_code, refined_code, issues, summary)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (current_user["id"], body.mode, body.code, refined_code, json.dumps(issues), summary)
    )
    conn.commit()
    refinement_id = cursor.lastrowid
    conn.close()

    return {
        "refined_code": refined_code,
        "issues": issues,
        "summary": summary,
        "refinement_id": refinement_id
    }
