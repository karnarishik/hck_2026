from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from contextlib import asynccontextmanager
from database import init_db
from routers import auth, refine, history

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="PyRefine API",
    description="AI-powered Python code refiner backend",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change to your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(refine.router, prefix="/refine", tags=["Refine"])
app.include_router(history.router, prefix="/history", tags=["History"])

@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "PyRefine API is running 🚀"}

@app.get("/health", tags=["Health"])
def health():
    return {"status": "healthy"}
